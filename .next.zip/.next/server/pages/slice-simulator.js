"use strict";
(() => {
var exports = {};
exports.id = 807;
exports.ids = [807];
exports.modules = {

/***/ 7134:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _prismicio_slice_simulator_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1994);
/* harmony import */ var _prismicio_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2640);
/* harmony import */ var _prismicio_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_prismicio_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _slicemachine_libraries_state_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6071);
/* harmony import */ var _slices__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5611);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_prismicio_slice_simulator_react__WEBPACK_IMPORTED_MODULE_1__]);
_prismicio_slice_simulator_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const SliceSimulatorPage = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_prismicio_slice_simulator_react__WEBPACK_IMPORTED_MODULE_1__.SliceSimulator, {
        // The "sliceZone" prop should be a function receiving slices and rendering them using your "SliceZone" component.
        sliceZone: (props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_prismicio_react__WEBPACK_IMPORTED_MODULE_2__.SliceZone, {
                ...props,
                components: _slices__WEBPACK_IMPORTED_MODULE_4__/* .components */ .wx
            }),
        state: _slicemachine_libraries_state_json__WEBPACK_IMPORTED_MODULE_3__
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SliceSimulatorPage);
const getStaticProps = async ()=>{
    if (true) {
        return {
            notFound: true
        };
    } else {}
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2640:
/***/ ((module) => {

module.exports = require("@prismicio/react");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1994:
/***/ ((module) => {

module.exports = import("@prismicio/slice-simulator-react");;

/***/ }),

/***/ 6071:
/***/ ((module) => {

module.exports = JSON.parse('{"slices":{"components":{"card_linlks":{"library":"slices","id":"card_linlks","name":"CardLinlks","description":"CardLinlks","model":{"id":"card_linlks","type":"SharedSlice","name":"CardLinlks","description":"CardLinlks","variations":[{"id":"default","name":"Default","docURL":"...","version":"sktwi1xtmkfgx8626","description":"CardLinlks","primary":{"img":{"type":"Image","config":{"label":"img","constraint":{},"thumbnails":[]}},"title":{"type":"Text","config":{"label":"title","placeholder":""}},"link":{"type":"Link","config":{"label":"link","placeholder":"","select":null}}},"items":{},"imageUrl":"https://images.prismic.io/slice-machine/621a5ec4-0387-4bc5-9860-2dd46cbc07cd_default_ss.png?auto=compress,format"}]},"mocks":{"default":{"variation":"default","version":"sktwi1xtmkfgx8626","items":[{}],"primary":{"img":{"dimensions":{"width":900,"height":500},"alt":null,"copyright":null,"url":"https://images.unsplash.com/photo-1591012911207-0dbac31f37da"},"title":"bare","link":{"link_type":"Web","url":"https://slicemachine.dev"}},"slice_type":"card_linlks"}},"meta":{"fileName":"index","extension":"js"},"screenshotPaths":{}},"movie_cards":{"library":"slices","id":"movie_cards","name":"MovieCards","description":"MovieCards","model":{"id":"movie_cards","type":"SharedSlice","name":"MovieCards","description":"MovieCards","variations":[{"id":"default","name":"Default","docURL":"...","version":"sktwi1xtmkfgx8626","description":"MovieCards","primary":{},"items":{"overview":{"type":"StructuredText","config":{"label":"overview","placeholder":"","allowTargetBlank":true,"multi":"paragraph,preformatted,heading1,heading2,heading3,heading4,heading5,heading6,strong,em,hyperlink,image,embed,list-item,o-list-item,rtl"}},"popularity":{"type":"StructuredText","config":{"label":"popularity","placeholder":"","allowTargetBlank":true,"single":"strong,heading6"}},"image":{"type":"Image","config":{"label":"image","constraint":{},"thumbnails":[]}},"release_date":{"type":"StructuredText","config":{"label":"release_date","placeholder":"","allowTargetBlank":true,"single":"heading6,strong"}},"llink":{"type":"Link","config":{"label":"llink","placeholder":"","select":null}},"title":{"type":"Text","config":{"label":"title","placeholder":""}}},"imageUrl":"https://images.prismic.io/slice-machine/621a5ec4-0387-4bc5-9860-2dd46cbc07cd_default_ss.png?auto=compress,format"}]},"mocks":{"default":{"variation":"default","version":"sktwi1xtmkfgx8626","items":[{"overview":[{"type":"paragraph","text":"Ad ipsum eiusmod dolore. Cillum excepteur consectetur proident dolore dolor est non ea dolor. Proident sunt elit proident sit elit.","spans":[]}],"popularity":[{"type":"heading6","text":"Himself","spans":[]}],"image":{"dimensions":{"width":900,"height":500},"alt":null,"copyright":null,"url":"https://images.unsplash.com/photo-1545239351-1141bd82e8a6"},"release_date":[{"type":"heading6","text":"Enjoy","spans":[]}],"llink":{"link_type":"Web","url":"http://twitter.com"},"title":"rocky"}],"primary":{},"slice_type":"movie_cards"}},"meta":{"fileName":"index","extension":"js"},"screenshotPaths":{}}}}}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [611], () => (__webpack_exec__(7134)));
module.exports = __webpack_exports__;

})();