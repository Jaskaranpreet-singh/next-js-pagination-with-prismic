"use strict";
exports.id = 254;
exports.ids = [254];
exports.modules = {

/***/ 3139:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ enableAutoPreviews)
/* harmony export */ });
const isPrismicNextPreviewData = (previewData) => {
  return typeof previewData === "object" && "ref" in previewData;
};
const enableAutoPreviews = (config) => {
  if ("previewData" in config && config.previewData) {
    const { previewData } = config;
    if (isPrismicNextPreviewData(previewData) && previewData.ref) {
      config.client.queryContentFromRef(previewData.ref);
    }
  } else if ("req" in config && config.req) {
    config.client.enableAutoPreviewsFromReq(config.req);
  }
};

//# sourceMappingURL=enableAutoPreviews.js.map


/***/ }),

/***/ 815:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u": () => (/* binding */ redirectToPreviewURL)
/* harmony export */ });
const isPrismicNextQuery = (query) => {
  return typeof query.documentId === "string" && typeof query.token === "string";
};
async function redirectToPreviewURL(config) {
  const defaultURL = config.defaultURL || "/";
  const basePath = config.basePath || "";
  if (isPrismicNextQuery(config.req.query)) {
    const previewUrl = await config.client.resolvePreviewURL({
      linkResolver: config.linkResolver,
      defaultURL,
      documentID: config.req.query.documentId,
      previewToken: config.req.query.token
    });
    config.res.redirect(basePath + previewUrl);
    return;
  }
  config.res.redirect(basePath + defaultURL);
}

//# sourceMappingURL=redirectToPreviewURL.js.map


/***/ }),

/***/ 2965:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ setPreviewData)
/* harmony export */ });
/* harmony import */ var _prismicio_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4582);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_prismicio_client__WEBPACK_IMPORTED_MODULE_0__]);
_prismicio_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function setPreviewData({ req, res }) {
  const ref = req.query.token || req.cookies[_prismicio_client__WEBPACK_IMPORTED_MODULE_0__.cookie.preview];
  if (ref) {
    res.setPreviewData({ ref });
  }
}

//# sourceMappingURL=setPreviewData.js.map

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;