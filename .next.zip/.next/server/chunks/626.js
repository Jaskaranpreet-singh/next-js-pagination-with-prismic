"use strict";
exports.id = 626;
exports.ids = [626];
exports.modules = {

/***/ 3977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "ds": () => (/* binding */ incrementByAmount)
/* harmony export */ });
/* unused harmony exports counterSlice, increment, decrement */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    value: ""
};
const counterSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "counter",
    initialState,
    reducers: {
        increment: (state)=>{
            // Redux Toolkit allows us to write "mutating" logic in reducers. It
            // doesn't actually mutate the state because it uses the Immer library,
            // which detects changes to a "draft state" and produces a brand new
            // immutable state based off those changes
            state.value += 1;
        },
        decrement: (state)=>{
            state.value -= 1;
        },
        incrementByAmount: (state, action)=>{
            state.value = action.payload;
        }
    }
});
// Action creators are generated for each case reducer function
const { increment , decrement , incrementByAmount  } = counterSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (counterSlice.reducer);


/***/ }),

/***/ 688:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ repositoryName),
/* harmony export */   "e": () => (/* binding */ createClient)
/* harmony export */ });
/* harmony import */ var _prismicio_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4582);
/* harmony import */ var _prismicio_next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5596);
/* harmony import */ var _sm_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(125);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_prismicio_client__WEBPACK_IMPORTED_MODULE_0__]);
_prismicio_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



/**
 * The project's Prismic repository name.
 */ const repositoryName = _prismicio_client__WEBPACK_IMPORTED_MODULE_0__.getRepositoryName(_sm_json__WEBPACK_IMPORTED_MODULE_1__/* .apiEndpoint */ ._d);
/**
 * The project's Prismic Route Resolvers. This list determines a Prismic document's URL.
 *
 * @type {prismic.ClientConfig['routes']}
 */ const routes = [
    {
        type: "page",
        path: "/:uid"
    },
    {
        type: "page",
        uid: "home",
        path: "/"
    },
    {
        type: "settings",
        path: "/"
    },
    {
        type: "navigation",
        path: "/"
    }
];
/**
 * Creates a Prismic client for the project's repository. The client is used to
 * query content from the Prismic API.
 *
 * @param config {prismicNext.CreateClientConfig} - Configuration for the Prismic client.
 */ const createClient = ({ previewData , req , ...config } = {})=>{
    const client = _prismicio_client__WEBPACK_IMPORTED_MODULE_0__.createClient(_sm_json__WEBPACK_IMPORTED_MODULE_1__/* .apiEndpoint */ ._d, {
        routes,
        ...config
    });
    _prismicio_next__WEBPACK_IMPORTED_MODULE_2__/* .enableAutoPreviews */ .L({
        client,
        previewData,
        req
    });
    return client;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 125:
/***/ ((module) => {

module.exports = JSON.parse('{"_d":"https://thmoviedatabase9786e.prismic.io/api/v2"}');

/***/ })

};
;