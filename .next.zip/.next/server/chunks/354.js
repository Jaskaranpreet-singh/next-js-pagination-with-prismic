exports.id = 354;
exports.ids = [354];
exports.modules = {

/***/ 8354:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ PrismicPreview)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lib_getPrismicPreviewCookie_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7592);
/* harmony import */ var _lib_getPreviewCookieRepositoryName_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8010);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_getPrismicPreviewCookie_js__WEBPACK_IMPORTED_MODULE_4__]);
_lib_getPrismicPreviewCookie_js__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function PrismicPreview({
  repositoryName,
  children,
  updatePreviewURL = "/api/preview",
  exitPreviewURL = "/api/exit-preview"
}) {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const resolvedUpdatePreviewURL = router.basePath + updatePreviewURL;
  const resolvedExitPreviewURL = router.basePath + exitPreviewURL;
  react__WEBPACK_IMPORTED_MODULE_1__.useEffect(() => {
    const startPreviewMode = async () => {
      const res = await globalThis.fetch(resolvedUpdatePreviewURL);
      if (res.ok) {
        globalThis.location.reload();
      } else {
        console.error(`[<PrismicPreview>] Failed to start or update Preview Mode using the "${resolvedUpdatePreviewURL}" API endpoint. Does it exist?`);
      }
    };
    const handlePrismicPreviewUpdate = async (event) => {
      event.preventDefault();
      await startPreviewMode();
    };
    const handlePrismicPreviewEnd = async (event) => {
      event.preventDefault();
      const res = await globalThis.fetch(resolvedExitPreviewURL);
      if (res.ok) {
        globalThis.location.reload();
      } else {
        console.error(`[<PrismicPreview>] Failed to exit Preview Mode using the "${resolvedExitPreviewURL}" API endpoint. Does it exist?`);
      }
    };
    if (router.isPreview) {
      window.addEventListener("prismicPreviewUpdate", handlePrismicPreviewUpdate);
      window.addEventListener("prismicPreviewEnd", handlePrismicPreviewEnd);
    } else {
      const prismicPreviewCookie = (0,_lib_getPrismicPreviewCookie_js__WEBPACK_IMPORTED_MODULE_4__/* .getPrismicPreviewCookie */ .d)(globalThis.document.cookie);
      if (prismicPreviewCookie) {
        const locationIsDescendantOfBasePath = window.location.href.startsWith(window.location.origin + router.basePath);
        const prismicPreviewCookieRepositoryName = (0,_lib_getPreviewCookieRepositoryName_js__WEBPACK_IMPORTED_MODULE_5__/* .getPreviewCookieRepositoryName */ .o)(prismicPreviewCookie);
        if (locationIsDescendantOfBasePath && prismicPreviewCookieRepositoryName === repositoryName) {
          startPreviewMode();
        }
      }
    }
    return () => {
      window.removeEventListener("prismicPreviewUpdate", handlePrismicPreviewUpdate);
      window.removeEventListener("prismicPreviewEnd", handlePrismicPreviewEnd);
    };
  }, [repositoryName, resolvedExitPreviewURL, resolvedUpdatePreviewURL, router.isPreview, router.basePath]);
  return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [children, (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((next_script__WEBPACK_IMPORTED_MODULE_3___default()), {
      src: `https://static.cdn.prismic.io/prismic.js?repo=${repositoryName}&new=true`,
      strategy: "lazyOnload"
    })]
  });
}

//# sourceMappingURL=PrismicPreview.js.map

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8010:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ getPreviewCookieRepositoryName)
/* harmony export */ });
const getPreviewCookieRepositoryName = (previewCookie) => {
  return (decodeURIComponent(previewCookie).match(/"(.+).prismic.io"/) || [])[1];
};

//# sourceMappingURL=getPreviewCookieRepositoryName.js.map


/***/ }),

/***/ 7592:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ getPrismicPreviewCookie)
/* harmony export */ });
/* harmony import */ var _prismicio_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4582);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_prismicio_client__WEBPACK_IMPORTED_MODULE_0__]);
_prismicio_client__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const readValue = (value) => {
  return value.replace(/%3B/g, ";");
};
const getPrismicPreviewCookie = (cookieJar) => {
  const cookies = cookieJar.split("; ");
  let value;
  for (const cookie of cookies) {
    const parts = cookie.split("=");
    const name = readValue(parts[0]).replace(/%3D/g, "=");
    if (name === _prismicio_client__WEBPACK_IMPORTED_MODULE_0__.cookie.preview) {
      value = readValue(parts.slice(1).join("="));
      continue;
    }
  }
  return value;
};

//# sourceMappingURL=getPrismicPreviewCookie.js.map

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(3573)


/***/ })

};
;